// Simple front-end behaviour: handle lead form locally
document.getElementById('leadForm')?.addEventListener('submit', function(e){
  e.preventDefault();
  const frm = e.currentTarget;
  const data = {
    name: frm.name.value.trim(),
    email: frm.email.value.trim(),
    message: frm.message.value.trim()
  };
  if(!data.name || !data.email || !data.message){
    alert('Please fill all fields.');
    return;
  }
  // Compose email link (user's email client)
  const subject = encodeURIComponent('Neo Qhu - New Quote Request from ' + data.name);
  const body = encodeURIComponent('Name: ' + data.name + '\nEmail: ' + data.email + '\n\n' + data.message);
  window.location.href = 'mailto:neocricket66@gmail.com?subject=' + subject + '&body=' + body;
});
