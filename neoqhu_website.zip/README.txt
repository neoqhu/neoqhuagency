
Neo Qhu - Robotic Website (static)
Files included:
- index.html
- styles.css
- script.js

How to preview locally:
1) Unzip the folder and open index.html in your browser.

How to publish to the URL (www.neoqhuagency.com):
Option A — Netlify (easiest, supports custom domains):
  1. Create a Netlify account (free tier).
  2. Drag & drop the unzipped folder into Sites -> New site from drag & drop.
  3. In Site settings -> Domain management, add your custom domain (www.neoqhuagency.com).
  4. Follow Netlify's steps to verify domain ownership (you'll need to update DNS at your domain registrar).
Option B — GitHub Pages:
  1. Create a GitHub repo and commit these files to the main branch.
  2. In repo Settings -> Pages, set source to main branch / root and save.
  3. For a custom domain, add the domain in Pages settings and update DNS records per GitHub instructions.
Option C — Purchase hosting & upload files (e.g., cPanel FTP) and point the domain to the hosting nameservers.

Need domain/DNS help?
If you don't own neoqhuagency.com yet, buy the domain through a registrar (Namecheap, GoDaddy, etc.) and then follow Netlify or GitHub instructions to connect it.

If you want, I can:
- Prepare the GitHub repo structure and a zip ready to upload to Netlify (this is included here).
- Customize copy, add images you upload, or integrate contact forms with third-party services.
